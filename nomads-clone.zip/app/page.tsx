import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

const SearchIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
    />
  </svg>
)

const HeartIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
    />
  </svg>
)

const StarIcon = () => (
  <svg className="w-4 h-4 fill-yellow-400 text-yellow-400" viewBox="0 0 24 24">
    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
  </svg>
)

const ThermometerIcon = () => (
  <svg className="w-4 h-4 text-orange-500" fill="currentColor" viewBox="0 0 24 24">
    <path d="M15 13V5a3 3 0 0 0-6 0v8a5 5 0 0 0 6 0z" />
    <circle cx="12" cy="16" r="1" />
  </svg>
)

const WifiIcon = () => (
  <svg className="w-4 h-4 text-blue-500" fill="currentColor" viewBox="0 0 24 24">
    <path d="M1 9l2 2c4.97-4.97 13.03-4.97 18 0l2-2C16.93 2.93 7.07 2.93 1 9zm8 8l3 3 3-3c-1.65-1.66-4.34-1.66-6 0zm-4-4l2 2c2.76-2.76 7.24-2.76 10 0l2-2C15.14 9.14 8.87 9.14 5 13z" />
  </svg>
)

const ChevronDownIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
  </svg>
)

const GridIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z"
    />
  </svg>
)

const ListIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
  </svg>
)

const destinations = [
  {
    id: 1,
    name: "Bangkok",
    country: "Thailand",
    image: "/bangkok-skyline-with-temples.jpg",
    price: 1508,
    rating: 4.8,
    reviews: 2847,
    temperature: 32,
    wifi: 85,
    safety: 4.2,
    fun: 4.6,
    cost: 4.8,
    rank: 1,
  },
  {
    id: 2,
    name: "Lisbon",
    country: "Portugal",
    image: "/lisbon-colorful-buildings-and-trams.jpg",
    price: 2887,
    rating: 4.7,
    reviews: 1923,
    temperature: 24,
    wifi: 92,
    safety: 4.5,
    fun: 4.4,
    cost: 3.8,
    rank: 2,
  },
  {
    id: 3,
    name: "Chiang Mai",
    country: "Thailand",
    image: "/chiang-mai-temples-and-mountains.jpg",
    price: 1603,
    rating: 4.6,
    reviews: 1567,
    temperature: 29,
    wifi: 88,
    safety: 4.3,
    fun: 4.2,
    cost: 4.7,
    rank: 3,
  },
  {
    id: 4,
    name: "Berlin",
    country: "Germany",
    image: "/berlin-brandenburg-gate-and-modern-architecture.jpg",
    price: 3449,
    rating: 4.4,
    reviews: 2156,
    temperature: 18,
    wifi: 95,
    safety: 4.6,
    fun: 4.5,
    cost: 3.2,
    rank: 4,
  },
  {
    id: 5,
    name: "Canggu, Bali",
    country: "Indonesia",
    image: "/bali-rice-terraces-and-tropical-landscape.jpg",
    price: 2018,
    rating: 4.5,
    reviews: 1834,
    temperature: 31,
    wifi: 82,
    safety: 4.1,
    fun: 4.7,
    cost: 4.4,
    rank: 5,
  },
  {
    id: 6,
    name: "Dubai",
    country: "UAE",
    image: "/dubai-skyline-burj-khalifa.png",
    price: 4062,
    rating: 4.3,
    reviews: 987,
    temperature: 35,
    wifi: 98,
    safety: 4.8,
    fun: 4.1,
    cost: 2.8,
    rank: 6,
  },
  {
    id: 7,
    name: "London",
    country: "United Kingdom",
    image: "/london-big-ben-and-thames-river.jpg",
    price: 5789,
    rating: 4.2,
    reviews: 3421,
    temperature: 15,
    wifi: 96,
    safety: 4.4,
    fun: 4.6,
    cost: 2.1,
    rank: 7,
  },
  {
    id: 8,
    name: "Porto",
    country: "Portugal",
    image: "/porto-colorful-riverside-buildings.jpg",
    price: 2245,
    rating: 4.6,
    reviews: 1456,
    temperature: 22,
    wifi: 89,
    safety: 4.5,
    fun: 4.3,
    cost: 4.1,
    rank: 8,
  },
  {
    id: 9,
    name: "Tbilisi",
    country: "Georgia",
    image: "/tbilisi-old-town-with-traditional-architecture.jpg",
    price: 2371,
    rating: 4.4,
    reviews: 892,
    temperature: 26,
    wifi: 85,
    safety: 4.2,
    fun: 4.0,
    cost: 4.6,
    rank: 9,
  },
  {
    id: 10,
    name: "Kuala Lumpur",
    country: "Malaysia",
    image: "/kuala-lumpur-petronas-towers-skyline.jpg",
    price: 1447,
    rating: 4.3,
    reviews: 1234,
    temperature: 33,
    wifi: 91,
    safety: 4.0,
    fun: 4.2,
    cost: 4.8,
    rank: 10,
  },
  {
    id: 11,
    name: "Warsaw",
    country: "Poland",
    image: "/warsaw-old-town-square-and-palace.jpg",
    price: 3407,
    rating: 4.1,
    reviews: 756,
    temperature: 19,
    wifi: 93,
    safety: 4.4,
    fun: 3.9,
    cost: 3.8,
    rank: 11,
  },
  {
    id: 12,
    name: "Mexico City",
    country: "Mexico",
    image: "/mexico-city-cathedral-and-historic-center.jpg",
    price: 1925,
    rating: 4.2,
    reviews: 1678,
    temperature: 24,
    wifi: 87,
    safety: 3.8,
    fun: 4.5,
    cost: 4.5,
    rank: 12,
  },
]

export default function NomadsClone() {
  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
        <div className="max-w-full mx-auto px-4">
          <div className="flex items-center justify-between h-12">
            <div className="flex items-center space-x-6">
              <div className="flex items-center">
                <div className="w-6 h-6 bg-red-500 rounded-sm flex items-center justify-center">
                  <span className="text-white font-bold text-xs">N</span>
                </div>
                <span className="ml-2 text-lg font-semibold text-white">Nomads</span>
              </div>
              <nav className="hidden md:flex items-center space-x-4 text-sm">
                <a href="#" className="text-gray-300 hover:text-white">
                  Cities
                </a>
                <a href="#" className="text-gray-300 hover:text-white">
                  Countries
                </a>
                <a href="#" className="text-gray-300 hover:text-white">
                  Trips
                </a>
                <a href="#" className="text-gray-300 hover:text-white">
                  Chat
                </a>
              </nav>
            </div>

            <div className="flex items-center space-x-3">
              <Button variant="ghost" size="sm" className="text-xs text-gray-300 hover:text-white hover:bg-gray-700">
                <GridIcon />
              </Button>
              <Button variant="ghost" size="sm" className="text-xs text-gray-300 hover:text-white hover:bg-gray-700">
                Sort: Overall <ChevronDownIcon />
              </Button>
              <Button size="sm" className="bg-red-500 hover:bg-red-600 text-white text-xs px-3 py-1">
                Join
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-full mx-auto px-4 py-4">
        <div className="flex gap-4">
          {/* Sidebar */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-gray-800 rounded border border-gray-700 p-4 mb-4">
              <div className="relative mb-3">
                <div className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-400">
                  <SearchIcon />
                </div>
                <Input
                  placeholder="Search places..."
                  className="pl-8 h-8 text-sm bg-gray-700 border-gray-600 text-white placeholder-gray-400"
                />
              </div>

              {/* What Filters */}
              <div className="mb-6">
                <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">What</h4>

                {/* Temperature Filters */}
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🍦 Cold now
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🌤 Mild now
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      className="text-xs h-6 px-2 bg-red-500 hover:bg-red-600 text-white border border-red-500"
                    >
                      ☀️ Warm now
                    </Button>
                  </div>
                </div>

                {/* Cost Filters */}
                <div className="mb-3">
                  <div className="flex flex-wrap gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      💵&lt;US$1K/mo
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      💸&lt;US$2K/mo
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      💰&lt;US$3K/mo
                    </Button>
                  </div>
                </div>

                {/* Half-width filters in pairs */}
                <div className="grid grid-cols-2 gap-1 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    👮‍ Safe
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    📡 Fast internet
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-1 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    💨 Clean air now
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    👍 Liked by members
                  </Button>
                </div>

                <div className="grid grid-cols-2 gap-1 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    🔥 Popular now
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    📈 Growing in nomads
                  </Button>
                </div>

                {/* Top ranked / Hidden gem - Single choice pair */}
                <div className="flex gap-1 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600 flex-1"
                  >
                    🏅 Top ranked
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600 flex-1"
                  >
                    💎 Hidden gem
                  </Button>
                </div>

                {/* Personal filters */}
                <div className="grid grid-cols-2 gap-1 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    ✨ You haven't been
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    ✨ For you
                  </Button>
                </div>

                {/* Near location - half width */}
                <div className="grid grid-cols-2 gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    🇹🇭 Near Thailand
                  </Button>
                </div>
              </div>

              {/* Where Filters */}
              <div>
                <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Where</h4>

                {/* Regional Filters - Full width, multiple choice OR */}
                <div className="mb-3">
                  <div className="grid grid-cols-2 gap-1 mb-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🌎 North America
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      💃 Latin America
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-1 mb-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🇪🇺 Europe
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🌍 Africa
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-1 mb-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🕌 Middle East
                    </Button>
                    <Button
                      variant="default"
                      size="sm"
                      className="text-xs h-6 px-2 bg-red-500 hover:bg-red-600 text-white border border-red-500"
                    >
                      ⛩️ Asia
                    </Button>
                  </div>
                  <div className="grid grid-cols-2 gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🏄 Oceania
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                    >
                      🛰 Space
                    </Button>
                  </div>
                </div>

                {/* Country and region specific filters */}
                <div className="grid grid-cols-2 gap-1 mb-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    🇺🇸 United States
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    🏝 Caribbean
                  </Button>
                </div>

                <div className="grid grid-cols-1 gap-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    🇪🇺 European Union
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-xs h-6 px-2 text-gray-300 hover:bg-gray-700 hover:text-white border border-transparent hover:border-gray-600"
                  >
                    🇪🇺 Not in Schengen
                  </Button>
                </div>
              </div>
            </div>

            <div className="bg-gray-800 rounded border border-gray-700 p-4">
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Stats</h4>
              <div className="space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-400">Places</span>
                  <span className="font-medium text-white">1,247</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Members</span>
                  <span className="font-medium text-white">89,432</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Trips</span>
                  <span className="font-medium text-white">12,847</span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1">
            <div className="flex items-center justify-between mb-4">
              <h1 className="text-lg font-semibold text-white">Best places to live and work remotely</h1>
              <div className="text-xs text-gray-400">Showing 1-12 of 1,247 places</div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3">
              {destinations.map((destination) => (
                <div
                  key={destination.id}
                  className="bg-gray-800 border border-gray-700 rounded hover:shadow-lg hover:border-gray-600 transition-all cursor-pointer group"
                >
                  <div className="relative">
                    <img
                      src={destination.image || "/placeholder.svg"}
                      alt={destination.name}
                      className="w-full h-32 object-cover"
                    />
                    <div className="absolute top-2 left-2">
                      <Badge variant="secondary" className="bg-black/70 text-white text-xs px-1 py-0">
                        #{destination.rank}
                      </Badge>
                    </div>
                    <div className="absolute top-2 right-2">
                      <Button size="sm" variant="ghost" className="bg-black/70 hover:bg-black/90 p-1 h-6 w-6">
                        <HeartIcon />
                      </Button>
                    </div>
                  </div>

                  <div className="p-3">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h3 className="font-semibold text-sm leading-tight text-white">{destination.name}</h3>
                        <p className="text-gray-400 text-xs">{destination.country}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-semibold text-white">${destination.price}</div>
                        <div className="text-xs text-gray-400">/month</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-1">
                        <StarIcon />
                        <span className="text-xs font-medium text-white">{destination.rating}</span>
                        <span className="text-xs text-gray-400">({destination.reviews})</span>
                      </div>
                      <div className="flex items-center space-x-2 text-xs">
                        <div className="flex items-center space-x-1">
                          <ThermometerIcon />
                          <span className="text-white">{destination.temperature}°</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <WifiIcon />
                          <span className="text-white">{destination.wifi}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between text-xs">
                      <div className="flex space-x-2">
                        <span className="text-gray-400">Safety</span>
                        <span className="font-medium text-white">{destination.safety}</span>
                      </div>
                      <div className="flex space-x-2">
                        <span className="text-gray-400">Fun</span>
                        <span className="font-medium text-white">{destination.fun}</span>
                      </div>
                      <div className="flex space-x-2">
                        <span className="text-gray-400">Cost</span>
                        <span className="font-medium text-white">{destination.cost}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-6">
              <Button
                variant="outline"
                size="sm"
                className="text-sm bg-transparent border-gray-600 text-gray-300 hover:bg-gray-700 hover:text-white"
              >
                Load more places
              </Button>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="w-64 flex-shrink-0">
            <div className="bg-gray-800 rounded border border-gray-700 p-4 mb-4">
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Trending</h4>
              <div className="space-y-2">
                {destinations.slice(0, 4).map((dest) => (
                  <div
                    key={dest.id}
                    className="flex items-center space-x-2 p-1 hover:bg-gray-700 rounded cursor-pointer"
                  >
                    <img
                      src={dest.image || "/placeholder.svg"}
                      alt={dest.name}
                      className="w-8 h-8 rounded object-cover"
                    />
                    <div className="flex-1">
                      <p className="font-medium text-xs text-white">{dest.name}</p>
                      <p className="text-xs text-gray-400">${dest.price}/mo</p>
                    </div>
                    <div className="text-xs text-gray-400">#{dest.rank}</div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-gray-800 rounded border border-gray-700 p-4">
              <h4 className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-3">Community</h4>
              <div className="grid grid-cols-8 gap-1 mb-3">
                {Array.from({ length: 32 }).map((_, i) => (
                  <div key={i} className="w-6 h-6 bg-gray-600 rounded-full"></div>
                ))}
              </div>
              <p className="text-xs text-gray-400 mb-3">89,432+ nomads worldwide</p>
              <Button size="sm" className="w-full bg-red-500 hover:bg-red-600 text-xs">
                Join community
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
